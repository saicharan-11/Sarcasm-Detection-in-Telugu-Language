# Telugu POS tagger versions

## version 3.0
* Changes to Tokenizer
* Pipeline
* Git repository
