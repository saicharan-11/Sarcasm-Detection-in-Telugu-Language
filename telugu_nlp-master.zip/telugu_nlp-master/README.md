# telugu_nlp

Telugu lemmatization and pos-tag extraction code is taken from
https://bitbucket.org/sivareddyg/telugu-part-of-speech-tagger/src/master/

License:
The original model files are distributed under GNU GPL license.
